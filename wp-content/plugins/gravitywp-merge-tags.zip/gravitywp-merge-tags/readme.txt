=== Plugin Name ===
Contributors: GravityWP
Donate link: http://gravitywp.com/support/
Tags: gravity forms, mergetag, merge tag, mergetags, form, forms, gravity form
Requires at least: 3.0.1
Tested up to: 4.8.2
Stable tag: 4.8.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Adds a page to show all the merge tags from a specific Gravity Form. 

== Description ==
This Gravity Forms plugin adds a special page to your WordPress admin area with a list of all the merge tags in your form. No more clicking on a dropdown to select the merge tag you need, but just copy and paste it from the list. In addition to Merge Tags, it's also possible to get a list of Field Labels and a list of Field Types (like text, radio, hidden, checkbox, select, etc). 

The plugin adds a link in the toolbar above the Gravity Form you're working on and a menu link in de Forms submenu. 

== Installation ==

Upload the plugin files to the `/wp-content/plugins/gravitywp-merge-tags` directory, or install the plugin through the WordPress plugins screen directly.

== Frequently Asked Questions ==

= Where can I find the Merge Tags list =
You can click on 'Merge Tags' in the Toolbar above the Gravity Form you're working on. Or you can click on 'Merge Tags' in the Forms submenu. 
== Screenshots ==

1. List of Merge Tags from your Form (including short Merge Tags)
2. Standard Merge Tags from Gravity Forms, GravityView and Gravity Flow
3. List of Field Labels and Merge Tags
4. List of Fields with Field Type (like text, radio, hidden, checkbox, select, etc)
5. The menu link that gets added in the Gravity Form toolbar
6. The menu link under Forms (admin menu)

== Changelog ==
= 0.6 =
* Changed tabs layout to make it more convenient to copy and paste to Excel
* First tab with only Merge Tags from the current form
* Second tab (advanced) with more detailed information about the field: Label, Merge Tag, Short Merge Tag, Field Input Type
* Third tab with Standard Gravity Forms Merge Tags
* New tab (All Fields) to replace the allfields Merge Tag from Gravity Forms. It generates a table you can copy and paste and a table without fileuploads (in case you don't want to communicate links to files)

= 0.5 =
* Added Tabs 
* Styled the lists
* Added overview of Field Labels
* Added overview of Field Types
* Removed the shortcode for generating the Merge Tags list
* Added text-domain for translations

= 0.4 =
* Added Gravity Forms standard Merge Tags
* Added GravityView specific Merge Tags
* Added Gravity Flow specific Merge Tags

= 0.3 =
* Added admin page with all the merge tags of a specific form
* Added menu links in the sidebar and in the Gravity Forms toolbar

= 0.2 =
* Added check if Gravity Forms is installed
* Return instead of echo, so the list will be placed in the right place on the page

= 0.1 =
* First launch of the shortcode to show all merge tags
