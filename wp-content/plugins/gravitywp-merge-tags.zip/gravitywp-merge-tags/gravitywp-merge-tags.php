<?php
/*
Plugin Name: GravityWP - Merge Tags
Plugin URI: https://gravitywp.com/plugin/merge-tags
Description: Gravity Forms add-on to list all the merge tags from a specific form
Version: 0.6
Author: GravityWP
Author URI: https://gravitywp.com
License: GPL2
Text Domain: gravitywp-merge-tags
Domain Path: /languages
*/

define( 'GWP_MERGETAGS_VERSION', '0.6' );

add_action( 'gform_loaded', array( 'GWPMergeTags_AddOn_Bootstrap', 'load' ), 5 );

class GWPMergeTags_AddOn_Bootstrap {

    public static function load() {

        if ( ! method_exists( 'GFForms', 'include_addon_framework' ) ) {
            return;
        }

        require_once( 'class-gwp-mergetags.php' );

        GFAddOn::register( 'GWPMergeTags' );
    }

}

	add_filter( 'gform_toolbar_menu', 'gwpmergetags_toolbar', 10, 2 );
	function gwpmergetags_toolbar( $menu_items, $form_id ) {
		
		$menu_items['gwpmergetags_link'] = array(
			'label' => 'Merge Tags', // the text to display on the menu for this link
			'title' => 'Merge Tags', // the text to be displayed in the title attribute for this link
			'url' => self_admin_url( 'admin.php?page=gravitywp-merge-tags&id=' . $form_id ), // the URL this link should point to
			'menu_class' => 'gf_form_toolbar_custom_link', // optional, class to apply to menu list item (useful for providing a custom icon)
			'capabilities' => array( 'gravityforms_edit_forms' ), // the capabilities the user should possess in order to access this page
			'priority' => 500 // optional, use this to specify the order in which this menu item should appear; if no priority is provided, the menu item will be append to end
		);
		
		return $menu_items;
	}

	// Translation files of the plugin
	add_action('plugins_loaded', 'gwp_merge_tags_load_textdomain');
	function gwp_merge_tags_load_textdomain() {
		load_plugin_textdomain( 'gravitywp-merge-tags', false, dirname( plugin_basename(__FILE__) ) . '/languages' );
	}
	
	
	// GravityWP Modifiers
	add_filter( 'gform_merge_tag_filter', function ( $value, $merge_tag, $modifier, $field, $raw_value ) {
	if ( $merge_tag != 'all_fields' && $modifier == 'gwp_modifier_base64_encode' ) {
	$value = rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
	} return $value; }, 10, 5 );

	add_filter( 'gform_merge_tag_filter', function ( $value, $merge_tag, $modifier, $field, $raw_value ) {
	if ( $merge_tag != 'all_fields' && $modifier == 'gwp_modifier_base64_decode' ) {
	$value = base64_decode(strtr($value, '-_', '+/'));
	} return $value; }, 10, 5 );
	
	// GravityWP Merge Tags
	add_filter( 'gform_custom_merge_tags', 'gwp_merge_tag_list_comma', 10, 4 );
	add_filter( 'gform_merge_tag_filter', 'replace_gwp_merge_tag_list_comma', 10, 5 );

	function gwp_merge_tag_list_comma( $merge_tags, $form_id, $fields, $element_id ) {
    foreach ( $fields as $field ) {
        if ( 'list' == $field->get_input_type() ) {
            $columns = is_array( $field->choices );
            if ( $columns ) {
                foreach( $field->choices as $key => $choice ){
                    $key++; // add 1 as the choices array is zero based
                    $merge_tags[] = array(
                        'label' => $field->label . ' - ' . $choice['text']    . ' (comma separated)',
                        'tag' => '{' . $field->label . ':' . $field->id . ':' . $key . '}'
                    );
                }
            } else {
                $merge_tags[] = array(
                    'label' => $field->label . ' (comma separated)',
                    'tag' => '{' . $field->label . ':' . $field->id . ':1}'
                );
            }
        }
    }
    return $merge_tags;
	}

	function replace_gwp_merge_tag_list_comma ( $value, $merge_tag, $modifier, $field, $raw_value ) {
    if ( $field->get_input_type() == 'list' && $merge_tag != 'all_fields' && ! empty( $modifier ) ) {

        $column_values = array();

        // count the actual number of columns
        $choices = $field->choices;
        $column_count = count( $choices );

        if ( $column_count > 1 ) {
            // subtract 1 from column number as the choices array is zero based
            $column_num = $modifier - 1;

            // get the column label so we can use that as the key to the multi-column values
            $column = rgars( $choices, "{$column_num}/text" );

            // get the list fields values from the $entry
            $values = unserialize( $raw_value );

            foreach ( $values as $value ) {
                $column_values[] = rgar( $value, $column );
            }

            $value = GFCommon::implode_non_blank( ', ', $column_values );
        } else {
             // get the list fields values from the $entry
            $values = unserialize( $raw_value );

            foreach ( $values as $value ) {
                $column_values[] = $value;
            }

            $value = GFCommon::implode_non_blank( ', ', $column_values );
        }
    }

    return $value;
	}