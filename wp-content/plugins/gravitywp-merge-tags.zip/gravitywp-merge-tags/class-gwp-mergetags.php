<?php

GFForms::include_addon_framework();

class GWPMergeTags extends GFAddOn {

	protected $_version = GWP_MERGETAGS_VERSION;
	protected $_min_gravityforms_version = '1.9';
	protected $_slug = 'gravitywp-merge-tags';
	protected $_path = 'gravitywp-merge-tags/gravitywp-merge-tags.php';
	protected $_full_path = __FILE__;
	protected $_title = 'GravityWP Merge Tags';
	protected $_short_title = 'Merge Tags';

	private static $_instance = null;

	/**
	 * Get an instance of this class.
	 *
	 * @return GWPMergeTags
	 */
	public static function get_instance() {
		if ( self::$_instance == null ) {
			self::$_instance = new GWPMergeTags();
		}

		return self::$_instance;
	}

	// # ADMIN FUNCTIONS -----------------------------------------------------------------------------------------------

	/**
	 * Creates a custom page for this add-on.
	 */
	public function plugin_page() {

		if (!empty($_GET['id'])) {
			
		$active_tab = isset( $_GET[ 'tab' ] ) ? $_GET[ 'tab' ] : 'merge-tags';
		$form = RGFormsModel::get_form_meta($_GET['id']);
		?>
		<h2 class="nav-tab-wrapper">
		<a href="?page=gravitywp-merge-tags&id=<?php echo $_GET['id']; ?>&tab=merge-tags" class="nav-tab <?php echo $active_tab == 'merge-tags' ? 'nav-tab-active' : ''; ?>"><?php echo __( 'Merge Tags', 'gravitywp-merge-tags' ) . ' ' . $form["title"] ?></a>
		<a href="?page=gravitywp-merge-tags&id=<?php echo $_GET['id']; ?>&tab=merge-tags-advanced" class="nav-tab <?php echo $active_tab == 'merge-tags-advanced' ? 'nav-tab-active' : ''; ?>"><?php echo __( 'Merge Tags', 'gravitywp-merge-tags' ) . ' ' . __( 'Advanced', 'gravitywp-merge-tags' ) ?></a>
		<a href="?page=gravitywp-merge-tags&id=<?php echo $_GET['id']; ?>&tab=standard-merge-tags" class="nav-tab <?php echo $active_tab == 'standard-merge-tags' ? 'nav-tab-active' : ''; ?>"><?php echo __( 'Standard', 'gravitywp-merge-tags' ) . ' ' . __( 'Merge Tags', 'gravitywp-merge-tags' ) ?></a>
		<a href="?page=gravitywp-merge-tags&id=<?php echo $_GET['id']; ?>&tab=all-fields" class="nav-tab <?php echo $active_tab == 'all-fields' ? 'nav-tab-active' : ''; ?>"><?php echo __( 'All Fields', 'gravitywp-merge-tags' ) ?></a>
		</h2>
		
		<?php
			
			$fields = array();
			
			if( $active_tab == 'merge-tags' ) {
			echo "<p></p><table class='widefat fixed' cellspacing='0'><thead><tr><th>" . __( 'Merge Tags', 'gravitywp-merge-tags' ) . "</th></tr></thead><tbody>";
			if(is_array($form["fields"])){
				foreach($form["fields"] as $field){
					if(isset($field["inputs"]) && is_array($field["inputs"])){

						foreach($field["inputs"] as $input)
							echo "<tr><td>&#123;" . GFCommon::get_label($field, $input["id"]) . ":" . $input["id"] . "&#125;</td></tr>";
					}
					else if(!rgar($field, 'displayOnly')){
						echo "<tr><td>&#123;" . GFCommon::get_label($field) . ":" . $field["id"] . "&#125;</td></tr>";
					}
				}
			}

			}
			
			if( $active_tab == 'merge-tags-advanced' ) {
			echo "<p></p><table class='widefat fixed' cellspacing='0'><thead><tr><th>" . __( 'Field Label', 'gravitywp-merge-tags' ) . "</th><th>" . __( 'Merge Tag', 'gravitywp-merge-tags' ) . "</th><th>" . __( 'Merge Tags (short)', 'gravitywp-merge-tags' ) . "</th><th>" . __( 'Field Type', 'gravitywp-merge-tags' ) . "</th></tr></thead><tbody>";
			if(is_array($form["fields"])){
				foreach($form["fields"] as $field){
					if(isset($field["inputs"]) && is_array($field["inputs"])){
						foreach($field["inputs"] as $input)
							echo '<tr>
							<td style="width:50%">' . GFCommon::get_label($field, $input["id"]) . '</td>
							<td>&#123;' . GFCommon::get_label($field) . ':' . $field["id"] . '&#125;</td><td>&#123;:' . $input["id"] . '&#125;</td><td>' . RGFormsModel::get_input_type($field) . '</td></tr>';
					}
					else if(!rgar($field, 'displayOnly')){
						echo '<tr>
						<td style="width:50%">' . GFCommon::get_label($field) . '</td>
						<td>&#123;' . GFCommon::get_label($field) . ':' . $field["id"] . '&#125;</td><td>&#123;:' . $field["id"] . '&#125;</td><td>' . RGFormsModel::get_input_type($field) . '</td></tr>';
					}
				}
			}
			echo "</tbody></table>";
			}
				
			if( $active_tab == 'standard-merge-tags' ) {
			echo "<style>.gwp_div {width:32%; min-width: 300px; margin-right:1%; float:left !important;} .widefat {clear: none; }</style>";
			echo "<p></p><table class='widefat gwp_div' cellspacing='0'><thead><tr><td>Gravity Forms Merge Tags</td></tr></thead><tbody>";
			$gwp_standard_mergetags = array('all_fields', 'entry_id', 'entry_url', 'form_title', 'date_mdy', 'date_dmy', 'embed_url', 'ip', 'user_agent',  'referer', 'admin_email', 'currency', 'date_created', 'approval_status', 'is_fulfilled', 'payment_amount', 'payment_date', 'payment_method', 'payment_status', 'transaction_id', 'transaction_type', 'all_fields:admin', 'all_fields:value', 'all_fields:empty', 'all_fields:noadmin', 'all_fields:nohidden'  );
			foreach ($gwp_standard_mergetags as $gwp_standard_mergetag) {
				echo "<tr><td>&#123;" . $gwp_standard_mergetag . "&#125;</td></tr>";
			}
			echo "</tbody></table>";
			// Merge tags for GravityView
			echo "<table class='widefat gwp_div' cellspacing='0'><thead><tr><td><a href='https://gravityview.co/?ref=115' target='_blank'>GravityView</a></td></tr></thead><tbody>";
			$gwp_gv_mergetags = array('get', 'approval_status', 'approval_status:label', 'approval_status:value', 'date_created', 'date_created:time', 'date_created:format:m/d/Y', 'date_created:format:m/d/Y\ \a\t\ H\:i\:s', 'date_created:human',  'date_created:human:time', 'date_created:diff', 'ate_created:diff:format:I submitted %s in the past', 'created_by', 'created_by:ID', 'user:display_name', 'user:user_email', 'user:user_login', 'user:[meta_key]'  );
			foreach ($gwp_gv_mergetags as $gwp_gv_mergetag) {
				echo "<tr><td>&#123;" . $gwp_gv_mergetag . "&#125;</td></tr>";
			}
			echo "</tbody></table>";
			// Merge tags for Gravityflow
			echo "</a><table class='widefat gwp_div' cellspacing='0'><thead><tr><td><a href='https://gravityflow.io/?ref=2' target='_blank'>Gravity Flow</td></tr></thead><tbody>";
			$gwp_gflow_mergetags = array('workflow_entry_link', 'workflow_entry_url', 'workflow_inbox_link', 'workflow_inbox_url', 'workflow_cancel_link', 'workflow_cancel_url', 'workflow_note', 'workflow_timeline', 'assignees', 'workflow_approve_link', 'workflow_approve_url', 'workflow_reject_token' );
			foreach ($gwp_gflow_mergetags as $gwp_gflow_mergetag) {
				echo "<tr><td>&#123;" . $gwp_gflow_mergetag . "&#125;</td></tr>";
			}
			echo "</tbody></table>";
			
			}
			
			// All Fields Table tab
			if( $active_tab == 'all-fields' ) {
			echo "<p></p><table class='widefat fixed' cellspacing='0'><thead><tr><th>" . __( 'All Fields', 'gravitywp-merge-tags' ) .  " " . __( 'Type', 'gravitywp-merge-tags' ) . "</th><th>" . __( 'All Fields', 'gravitywp-merge-tags' ) . " " . __( 'Table', 'gravitywp-merge-tags' ) . "</th></tr></thead><tbody><tr><td>" . __( 'Replace All Fields Merge Tag', 'gravitywp-merge-tags' ) . "</td><td>&#60;table&#62;<br>";
			if(is_array($form["fields"])){
				foreach($form["fields"] as $field){
					if(isset($field["inputs"]) && is_array($field["inputs"])){

						foreach($field["inputs"] as $input)
							echo "&#60;tr&#62;&#60;td class='gwp-allfields-label' &#62;" . GFCommon::get_label($field, $input["id"]) . "&#60;/td&#62;<br>&#60;td class='gwp-allfields-value' &#62;&#123;" . GFCommon::get_label($field, $input["id"]) . ":" . $input["id"] . "&#125;&#60;/td&#62;&#60;/tr&#62;<br>";
					}
					else if(!rgar($field, 'displayOnly')){
						echo "&#60;tr&#62;&#60;td class='gwp-allfields-label' &#62;" . GFCommon::get_label($field, $input["id"]) . "&#60;/td&#62;<br>&#60;td class='gwp-allfields-value' &#62;&#123;" . GFCommon::get_label($field) . ":" . $field["id"] . "&#125;&#60;/td&#62;&#60;/tr&#62;<br>";
					}
				}
			}
			echo "&#60;/tbody&#62;&#60;/table&#62;</td></tr><tr><td>" . __( 'Replace All Fields Merge Tag', 'gravitywp-merge-tags' ) .  " " . __( 'without fileuploads', 'gravitywp-merge-tags' ) . "</td><td>&#60;table&#62;<br>";
			if(is_array($form["fields"])){
				foreach($form["fields"] as $field){
					if(isset($field["inputs"]) && is_array($field["inputs"])){

						foreach($field["inputs"] as $input)
							if (RGFormsModel::get_input_type($field) != "fileupload") {
							echo "&#60;tr&#62;&#60;td class='gwp-allfields-label' &#62;" . GFCommon::get_label($field, $input["id"]) . "&#60;/td&#62;<br>&#60;td class='gwp-allfields-value' &#62;&#123;" . GFCommon::get_label($field, $input["id"]) . ":" . $input["id"] . "&#125;&#60;/td&#62;&#60;/tr&#62;<br>";
							}
					}
					else if(!rgar($field, 'displayOnly')){
						if (RGFormsModel::get_input_type($field) != "fileupload") {
						echo "&#60;tr&#62;&#60;td class='gwp-allfields-label' &#62;" . GFCommon::get_label($field, $input["id"]) . "&#60;/td&#62;<br>&#60;td class='gwp-allfields-value' &#62;&#123;" . GFCommon::get_label($field) . ":" . $field["id"] . "&#125;&#60;/td&#62;&#60;/tr&#62;<br>";
						}
					}
				}
			}
			echo "&#60;/tbody&#62;&#60;/table&#62;</td></tr></tbody></table>";
			}
			
			
			
		} else {
			
			
			$forms = RGFormsModel::get_forms( null, 'title' );
			echo "<table class='widefat fixed' style='margin-top:10px;' cellspacing='0'><tr><thead><th>" . __( 'Select Form', 'gravitywp-merge-tags' ) . "</th></tr></thead><tbody>";
			foreach( $forms as $form ):
			 echo '<tr><td><a href="' . $_SERVER['REQUEST_URI'] . '&id=' . $form->id . '" target="_self">' . $form->title . '</a></td></tr>';
			endforeach;
			echo "</tbody></table>";
		
		}
	}        

	// # HELPERS -------------------------------------------------------------------------------------------------------

	/**
	 * The feedback callback for the 'mytextbox' setting on the plugin settings page and the 'mytext' setting on the form settings page.
	 *
	 * @param string $value The setting value.
	 *
	 * @return bool
	 */
	public function is_valid_setting( $value ) {
		return strlen( $value ) < 10;
	}

}