Cube Portfolio CSS, JS, IMAGES files:
	folder: /cubeportfolio

Documentation:
	folder: /documentation

Examples (demos):
	folder: /templates

Thank you for your purchase!
Mihai Buricea