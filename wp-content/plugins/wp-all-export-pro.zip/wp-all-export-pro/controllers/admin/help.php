<?php 
/**
 * Admin Help page
 * 
 * @author Pavel Kulbakin <p.kulbakin@gmail.com>
 */
class PMXE_Admin_Help extends PMXE_Controller_Admin {
	
	public function index() {
		$this->render();
	}
}