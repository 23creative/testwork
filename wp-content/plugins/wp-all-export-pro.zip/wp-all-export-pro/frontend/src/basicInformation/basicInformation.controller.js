GoogleMerchants.controller('basicInformationController', ['$scope', function($scope){
    
}]);